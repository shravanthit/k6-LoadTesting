import http from 'k6/http';
import { sleep } from 'k6';
import {check} from 'k6';
import { htmlReport } from "https://raw.githubusercontent.com/benc-uk/k6-reporter/main/dist/bundle.js";

export const options = {
  scenarios: {
    constant_request_rate: {
      executor: 'constant-arrival-rate',
      rate: 1000,
      timeUnit: '1s', // 1000 iterations per second, i.e. 1000 RPS
      duration: '30s',
      preAllocatedVUs: 100, // how large the initial pool of VUs would be
      maxVUs: 200, // if the preAllocatedVUs are not enough, we can initialize more
    },
  },
};


export let options1 ={
vus:1,
duration:'1000s'
};

export function handleSummary(data) {
  return {
    "summary.html": htmlReport(data),
  };
}

export default()=>{
const res = http.get('https://random-words5.p.rapidapi.com/getRandom');
const params = {
    headers: {
    'X-Mashape-Key': 'c429c77a44msha08e33cb055ccb4p127825jsn4a21f98f353a',
      'X-RapidAPI-Host': 'random-words5.p.rapidapi.com',

    },
    timeout:2000,
  };

console.log(res.body);
/*
check(res,{
'is status 200':(r)=>r.status ===200,
'body contains': r=>r.body.includes('{"message":"Too many requests"}'),
});*/
};